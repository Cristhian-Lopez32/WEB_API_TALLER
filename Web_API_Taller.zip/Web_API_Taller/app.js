/*************************************************************************
  * CONFIG
  *************************************************************************/
const RAWG_KEY = '728b37852c1546b4a4c9ed679833b63d' // clave en frontend: solo para pruebas
const DEVELOPER_NAME_SLUG = 'ubisoft'
let DEVELOPER_ID = null
const PAGE_SIZE = 40 // Incrementado para obtener más resultados

/*************************************************************************
  * ELEMENTS & STATE
  *************************************************************************/
const el = id => document.getElementById(id)
const grid = el('gamesGrid')
const status = el('status')
const errBox = el('error')
const loadMoreBtn = el('loadMore')
const spinner = el('spinner')
const loadBtn = el('loadBtn')
const refreshBtn = el('refreshBtn')

let timers = {}
let currentPage = 1
let lastFetchCount = 0
let isLoading = false
let allGames = [] // Cache en memoria para todos los juegos cargados

/* Helper: set loading UI state */
function setLoading(on){
  isLoading = !!on
  status.setAttribute('aria-busy', String(!!on))
  if(on){
    spinner.classList.add('show')
    loadBtn.disabled = true; loadMoreBtn.disabled = true; refreshBtn.disabled = true
  } else {
    spinner.classList.remove('show')
    loadBtn.disabled = false; loadMoreBtn.disabled = false; refreshBtn.disabled = false
  }
}

function humanizeRemaining(ms){
  if(ms <= 0) return null
  const s = Math.floor(ms/1000)
  const days = Math.floor(s/86400)
  const hours = Math.floor((s%86400)/3600)
  const mins = Math.floor((s%3600)/60)
  const secs = s%60
  return {days,hours,mins,secs}
}

function clearAllTimers(){ Object.values(timers).forEach(i=>clearInterval(i)); timers = {} }

/*************************************************************************
  * CARD / ACCESSIBLE markup
  *************************************************************************/
function createCard(game){
  const card = document.createElement('article')
  card.className = 'card'
  card.dataset.id = game.id
  card.setAttribute('role','listitem')
  card.tabIndex = 0

  const thumb = document.createElement('div'); thumb.className = 'thumb'
  const img = document.createElement('img')
  img.src = game.background_image || placeholderDataUrl(game.name)
  img.alt = game.name ? `${game.name} — portada` : 'Portada'
  img.loading = 'lazy'
  thumb.appendChild(img)

  // header
  const title = document.createElement('h3'); title.className = 'title'; title.textContent = game.name
  const sub = document.createElement('p'); sub.className = 'sub'; sub.textContent = game.short_description || (game.released ? 'Lanzamiento: ' + game.released : 'Por anunciar')

  // countdown
  const countdownWrap = document.createElement('div'); countdownWrap.className = 'countdown'; countdownWrap.setAttribute('aria-live','polite')
  const d = document.createElement('div'); d.className='time-block'; d.dataset.part='days'
  const h = document.createElement('div'); h.className='time-block'; h.dataset.part='hours'
  const m = document.createElement('div'); m.className='time-block'; m.dataset.part='mins'
  const s = document.createElement('div'); s.className='time-block'; s.dataset.part='secs'
  countdownWrap.append(d,h,m,s)

  // tags
  const tags = document.createElement('div'); tags.className = 'tags'
  if(game.genres && game.genres.length) game.genres.slice(0,2).forEach(g => { const t=document.createElement('span'); t.className='tag'; t.textContent=g.name; tags.appendChild(t) })
  if(game.platforms && game.platforms.length) game.platforms.slice(0,3).forEach(p => { const t=document.createElement('span'); t.className='tag'; t.textContent = p.platform.name; tags.appendChild(t) })

  // footer
  const footer = document.createElement('div'); footer.style.display='flex'; footer.style.justifyContent='space-between'; footer.style.alignItems='center'
  const leftInfo = document.createElement('div'); leftInfo.className='sub'; leftInfo.textContent = game.released ? new Date(game.released).toLocaleDateString() : 'TBA'
  const btn = document.createElement('button'); btn.className='btn'; btn.textContent='Recordarme'; btn.setAttribute('aria-label','Recordarme '+game.name)
  btn.addEventListener('click', ()=> alert('Recordatorio (demo) para: ' + game.name))
  footer.appendChild(leftInfo); footer.appendChild(btn)

  // assemble
  card.appendChild(thumb)
  card.appendChild(title)
  card.appendChild(sub)
  card.appendChild(countdownWrap)
  card.appendChild(tags)
  card.appendChild(footer)

  // keyboard: Enter opens recordarme (same as click)
  card.addEventListener('keydown', (ev) => {
    if(ev.key === 'Enter') btn.click()
  })

  // start countdown
  startCountdown(game.id, game.released, countdownWrap)
  return card
}

function startCountdown(id, releaseDateStr, container){
  if(timers[id]) clearInterval(timers[id])

  function tick(){
    const blocks = container.querySelectorAll('.time-block')
    if(!releaseDateStr){
      blocks[0].textContent = '—'; blocks[1].textContent = 'TBA'; blocks[2].textContent=''; blocks[3].textContent=''
      clearInterval(timers[id]); return
    }
    const now = new Date(), target = new Date(releaseDateStr), rem = target - now
    const parts = humanizeRemaining(rem)
    if(!parts){
      blocks[0].textContent = '—'; blocks[1].textContent = 'Disponible'; blocks[2].textContent=''; blocks[3].textContent=''
      clearInterval(timers[id]); return
    }
    blocks[0].textContent = parts.days + 'd'
    blocks[1].textContent = String(parts.hours).padStart(2,'0') + 'h'
    blocks[2].textContent = String(parts.mins).padStart(2,'0') + 'm'
    blocks[3].textContent = String(parts.secs).padStart(2,'0') + 's'
  }

  tick()
  timers[id] = setInterval(tick, 1000)
}

// --- FUNCIÓN MEJORADA PARA OBTENER EL ID DEL DESARROLLADOR ---
async function getDeveloperIdByName(name){
  const params = new URLSearchParams({
    search: name,
    key: RAWG_KEY,
    page_size: 10
  })
  const url = `https://api.rawg.io/api/developers?${params.toString()}`
  const res = await fetch(url)
  if(!res.ok) throw new Error(`Error al buscar desarrollador: ${res.status} ${res.statusText}`)
  const data = await res.json()
  console.log('Desarrolladores encontrados:', data)
  if(data.results && data.results.length > 0){
    // Primero buscar coincidencia exacta, sino el que más se parezca
    let dev = data.results.find(d => d.name.toLowerCase() === name.toLowerCase())
    if(!dev) dev = data.results.find(d => d.name.toLowerCase().includes(name.toLowerCase()))
    if(!dev) dev = data.results[0] // Como último recurso, tomar el primero
    console.log('Desarrollador seleccionado:', dev)
    return dev ? dev.id : null
  }
  return null
}

/*************************************************************************
  * FUNCIÓN MEJORADA PARA FETCH RAWG con diferentes estrategias de búsqueda
  *************************************************************************/
async function fetchUpcomingRawg(daysAhead = 730, page = 1){
  if(!RAWG_KEY) throw new Error('Falta RAWG API key.')
  
  // Aseguramos que tenemos el ID del desarrollador
  if (!DEVELOPER_ID) {
    DEVELOPER_ID = await getDeveloperIdByName(DEVELOPER_NAME_SLUG)
    if (!DEVELOPER_ID) {
      console.warn('No se pudo encontrar el ID del desarrollador. Intentando búsqueda por nombre...')
      return await fetchBySearch(daysAhead, page)
    }
  }

  // Determinar rango de fechas basado en la selección
  const timeRange = document.getElementById('timeRange').value
  let dateFilter = ''
  
  if(timeRange === 'upcoming'){
    const desde = new Date().toISOString().slice(0,10)
    const hastaDate = new Date(Date.now() + daysAhead * 24 * 60 * 60 * 1000)
    const hasta = hastaDate.toISOString().slice(0,10)
    dateFilter = `${desde},${hasta}`
  } else if(timeRange === 'recent'){
    // Últimos 6 meses y próximos X días
    const desde = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString().slice(0,10)
    const hastaDate = new Date(Date.now() + daysAhead * 24 * 60 * 60 * 1000)
    const hasta = hastaDate.toISOString().slice(0,10)
    dateFilter = `${desde},${hasta}`
  }
  // Si es 'all', no agregamos filtro de fecha

  const params = new URLSearchParams({
    developers: DEVELOPER_ID,
    page_size: String(PAGE_SIZE),
    page: String(page),
    key: RAWG_KEY,
    ordering: '-released,-added' // Ordenar por fecha de lanzamiento y fecha de agregado
  })

  if(dateFilter) {
    params.set('dates', dateFilter)
  }

  const url = `https://api.rawg.io/api/games?${params.toString()}`
  console.log('Fetching URL:', url)
  
  let res
  try {
    res = await fetch(url)
  } catch (networkErr){
    networkErr.isNetwork = true
    throw networkErr
  }
  if(!res.ok){
    const txt = await res.text().catch(()=>'')
    const err = new Error(`RAWG ${res.status} ${res.statusText} ${txt}`)
    err.status = res.status
    throw err
  }
  const data = await res.json()
  console.log('RAWG response (page', page + '):', data)
  
  // Si no obtuvimos resultados con el developer ID, intentar búsqueda por nombre
  if(!data.results || data.results.length === 0) {
    console.log('No se encontraron resultados con developer ID, intentando búsqueda por nombre...')
    return await fetchBySearch(daysAhead, page)
  }
  
  return data
}

// Función alternativa para buscar por nombre del desarrollador
async function fetchBySearch(daysAhead = 730, page = 1){
  const timeRange = document.getElementById('timeRange').value
  let dateFilter = ''
  
  if(timeRange === 'upcoming'){
    const desde = new Date().toISOString().slice(0,10)
    const hastaDate = new Date(Date.now() + daysAhead * 24 * 60 * 60 * 1000)
    const hasta = hastaDate.toISOString().slice(0,10)
    dateFilter = `${desde},${hasta}`
  } else if(timeRange === 'recent'){
    const desde = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString().slice(0,10)
    const hastaDate = new Date(Date.now() + daysAhead * 24 * 60 * 60 * 1000)
    const hasta = hastaDate.toISOString().slice(0,10)
    dateFilter = `${desde},${hasta}`
  }

  const params = new URLSearchParams({
    search: 'ubisoft',
    page_size: String(PAGE_SIZE),
    page: String(page),
    key: RAWG_KEY,
    ordering: '-released,-added'
  })

  if(dateFilter) {
    params.set('dates', dateFilter)
  }

  const url = `https://api.rawg.io/api/games?${params.toString()}`
  console.log('Fetching by search URL:', url)
  
  const res = await fetch(url)
  if(!res.ok){
    const txt = await res.text().catch(()=>'')
    const err = new Error(`RAWG ${res.status} ${res.statusText} ${txt}`)
    err.status = res.status
    throw err
  }
  const data = await res.json()
  
  // Filtrar resultados que realmente sean de Ubisoft
  if(data.results) {
    data.results = data.results.filter(game => {
      const hasUbisoft = game.developers && game.developers.some(dev => 
        dev.name.toLowerCase().includes('ubisoft')
      )
      const hasUbisoftPublisher = game.publishers && game.publishers.some(pub => 
        pub.name.toLowerCase().includes('ubisoft')
      )
      return hasUbisoft || hasUbisoftPublisher
    })
  }
  
  console.log('Filtered search results:', data)
  return data
}

/*************************************************************************
  * CACHE: localStorage simple caching
  *************************************************************************/
const CACHE_KEY = 'ubisoft_upcoming_cache_v2'
function saveCache(obj){ try { localStorage.setItem(CACHE_KEY, JSON.stringify({ts:Date.now(), payload:obj})) } catch(e){} }
function loadCache(){
  try{
    const raw = localStorage.getItem(CACHE_KEY); if(!raw) return null
    const parsed = JSON.parse(raw)
    // cache válido por 4 horas (14400000 ms)
    if(Date.now() - (parsed.ts||0) > 4*60*60*1000) return null
    return parsed.payload
  } catch(e){ return null }
}

/*************************************************************************
  * LOAD & RENDER (con soporte 'Cargar más' y filtros)
  *************************************************************************/
function populateGenreFilter(rawResults){
  const sel = document.getElementById('genre')
  const known = new Set()
  rawResults.forEach(g => { if(g.genres) g.genres.forEach(gg => known.add(gg.name)) })
  const current = sel.value || 'all'
  sel.innerHTML = '<option value="all">Todos los géneros</option>'
  Array.from(known).sort().forEach(name => {
    const o = document.createElement('option'); o.value = name; o.textContent = name; sel.appendChild(o)
  })
  sel.value = current
}

async function loadAndRender(reset = true){
  errBox.innerHTML = ''; setLoading(true)
  
  const days = parseInt(document.getElementById('daysAhead').value,10) || 730
  const q = document.getElementById('q').value.trim().toLowerCase()
  const genreSel = document.getElementById('genre').value
  const platformSel = document.getElementById('platform').value
  
  if(reset){
    clearAllTimers(); grid.innerHTML=''; currentPage = 1; allGames = []
    status.textContent = 'Estado: cargando lanzamientos...'
  }
  
  try{
    // Si es una carga inicial, intenta mostrar el caché
    if(reset){
      const cached = loadCache()
      if(cached && cached.results && cached.results.length){
        const itemsCached = (cached.results || []).map(mapRawgToGame)
        allGames = itemsCached
        populateGenreFilter(cached.results || [])
        applyFiltersAndRender()
        status.textContent = `Estado: mostrando datos cacheados (${grid.children.length})`
      }
    }
    
    const raw = await fetchUpcomingRawg(days, currentPage)
    const newItems = (raw.results || []).map(mapRawgToGame)
    
    if(reset){
      allGames = newItems
    } else {
      // Evitar duplicados
      const existingIds = new Set(allGames.map(g => g.id))
      const uniqueNewItems = newItems.filter(g => !existingIds.has(g.id))
      allGames = allGames.concat(uniqueNewItems)
    }
    
    // Controlar el botón "Cargar más"
    lastFetchCount = raw.results ? raw.results.length : 0
    if(raw.next && lastFetchCount > 0) {
      loadMoreBtn.style.display = 'inline-block'
      currentPage++
    } else {
      loadMoreBtn.style.display = 'none'
    }
    
    if(reset){
        populateGenreFilter(raw.results || [])
        applyFiltersAndRender();
    } else {
        // Si no es un reset, solo agregamos los nuevos elementos
        const filteredNewItems = newItems.filter(g => {
            if(genreSel !== 'all' && (!g.genres || !g.genres.some(x => x.name === genreSel))) return false
            if(platformSel !== 'all' && (!g.platforms || !g.platforms.some(p => p.platform && p.platform.name && p.platform.name.includes(platformSel)))) return false
            if(q && !g.name.toLowerCase().includes(q)) return false
            return true
        })
        
        // Evitar duplicados en la UI también
        const existingCardIds = new Set(Array.from(grid.children).map(card => card.dataset.id))
        filteredNewItems.filter(g => !existingCardIds.has(String(g.id))).forEach(g => grid.appendChild(createCard(g)))
    }

    status.textContent = `Estado: ${grid.children.length} resultado(s) mostrados de ${allGames.length} juegos totales`
    
    // save cache for future quick loads (only first page)
    if(reset && currentPage === 1) saveCache(raw)
  } catch(err){
    console.error('Fetch error:', err)
    if(err.isNetwork){
      errBox.innerHTML = `<div class="error">Error de red o CORS. Revisa tu conexión o usa un backend. <button id="retryNetwork" class="btn" style="margin-left:0.5rem">Reintentar</button></div>`
      document.getElementById('retryNetwork').addEventListener('click', ()=> loadAndRender(false))
    } else if(err.status === 401 || err.status === 403){
      errBox.innerHTML = `<div class="error">Error de autorización (401/403). Revisa tu API key.</div>`
    } else if(err.status === 429){
      errBox.innerHTML = `<div class="error">Límite alcanzado (429). Espera y prueba de nuevo más tarde.</div>`
    } else {
      errBox.innerHTML = `<div class="error">Error al consultar RAWG: ${escapeHtml(err.message || 'desconocido')}. <button id="retryBtn" class="btn" style="margin-left:0.5rem">Reintentar</button></div>`
      document.getElementById('retryBtn') && document.getElementById('retryBtn').addEventListener('click', ()=> loadAndRender(false))
    }
    // focus the error for screen readers
    errBox.querySelector && errBox.querySelector('*') && errBox.querySelector('*').focus && errBox.querySelector('*').focus()
    status.textContent = 'Estado: error'
  } finally {
    setTimeout(()=> setLoading(false), 200) // pequeño retardo para evitar parpadeos
  }
}

function applyFiltersAndRender() {
    clearAllTimers(); grid.innerHTML=''; 
    const q = document.getElementById('q').value.trim().toLowerCase()
    const genreSel = document.getElementById('genre').value
    const platformSel = document.getElementById('platform').value
    
    const filtered = allGames.filter(g => {
        if(genreSel !== 'all' && (!g.genres || !g.genres.some(x => x.name === genreSel))) return false
        if(platformSel !== 'all' && (!g.platforms || !g.platforms.some(p => p.platform && p.platform.name && p.platform.name.includes(platformSel)))) return false
        if(q && !g.name.toLowerCase().includes(q)) return false
        return true
    })

    filtered.forEach(g => grid.appendChild(createCard(g)))
    status.textContent = `Estado: ${grid.children.length} resultado(s) mostrados de ${allGames.length} juegos totales`
}

function mapRawgToGame(g){
  return {
    id: g.id,
    name: g.name,
    released: g.released || null,
    background_image: g.background_image || '',
    genres: g.genres || [],
    platforms: g.platforms || [],
    short_description: getGameDescription(g)
  }
}

function getGameDescription(game) {
  if(game.released) {
    const releaseDate = new Date(game.released)
    const now = new Date()
    if(releaseDate > now) {
      return 'Próximamente'
    } else {
      return 'Lanzado el ' + releaseDate.toLocaleDateString()
    }
  }
  return 'Por anunciar'
}

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])) }

/*************************************************************************
  * UI events
  *************************************************************************/
loadBtn.addEventListener('click', ()=> loadAndRender(true))
refreshBtn.addEventListener('click', ()=> loadAndRender(true))
el('q').addEventListener('input', ()=> setTimeout(applyFiltersAndRender, 350))
el('genre').addEventListener('change', ()=> applyFiltersAndRender())
el('platform').addEventListener('change', ()=> applyFiltersAndRender())
el('timeRange').addEventListener('change', ()=> loadAndRender(true))
el('notifyAll').addEventListener('click', ()=> alert('Demo: se crearían recordatorios para los visibles.'))

loadMoreBtn.addEventListener('click', async ()=>{
  await loadAndRender(false)
  // focus first new item for accessibility
  const firstNew = grid.querySelector(`[data-id]`)
  firstNew && firstNew.scrollIntoView({behavior:'smooth', block:'start'})
})

// initial: try cache then fetch fresh
(async ()=> {
  const cached = loadCache()
  if(cached && cached.results && cached.results.length){
    const items = (cached.results||[]).map(mapRawgToGame)
    allGames = items
    populateGenreFilter(cached.results || [])
    applyFiltersAndRender()
    status.textContent = `Estado: mostrando datos cacheados (${grid.children.length})`
  }
  try { await loadAndRender(true) } catch(e){ console.warn('Carga inicial fallida', e) }
})()

/*************************************************************************
  * placeholder image generator (SVG data URL) for missing covers
  *************************************************************************/
function placeholderDataUrl(title='Juego'){
  const txt = escapeHtml(title).slice(0,30)
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='800' height='450'><rect width='100%' height='100%' fill='#06101a'/><text x='50%' y='50%' fill='#4da7ff' font-size='36' text-anchor='middle' dominant-baseline='middle' font-family='Arial,sans-serif'>${txt}</text></svg>`
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg)
}
